document.addEventListener('DOMContentLoaded', () => {
    // 1. Select the DOM elements
    const hamburgerBtn = document.getElementById('hamburger-btn');
    const navMenu = document.getElementById('nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');
    const productGrid = document.getElementById('product-grid');
    const modal = document.getElementById('quick-view-modal');
    const modalBody = document.getElementById('modal-body');
    const closeBtn = document.querySelector('.close-btn');

    // Helper: Star Rating Generator
    function getStars(rate) {
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            stars += i <= Math.round(rate) ? '★' : '☆';
        }
        return stars;
    }


    // 2. Toggle Menu Functionality
    hamburgerBtn.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        hamburgerBtn.innerHTML = navMenu.classList.contains('active') ? '✕' : '☰';
    });

    // 3. Close menu when a link is clicked
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            hamburgerBtn.innerHTML = '☰';
        });
    });

    // 4. Fetch Products via AJAX (jQuery)
    function fetchProducts() {
        productGrid.innerHTML = '<div class="spinner"></div>'; // Show spinner
        $.ajax({
            url: 'https://fakestoreapi.com/products?limit=20',
            method: 'GET',
            success: function (products) {
                renderProducts(products);
            },
            error: function (error) {
                console.error('Error fetching products:', error);
                productGrid.innerHTML = '<p>Failed to load products. Please try again later.</p>';
            }
        });
    }

    // 5. Render Products Dynamically
    function renderProducts(products) {
        productGrid.innerHTML = ''; // Clear current static content

        products.forEach(product => {
            const productCard = `
                <div class="product-card">
                    <div class="category-tag">${product.category}</div>
                    <div class="product-image-container">
                         <img src="${product.image}" alt="${product.title}">
                    </div>
                    <h3>${product.title}</h3>
                    <div class="rating-row">
                        <span class="stars">${getStars(product.rating.rate)}</span>
                        <span class="rating-count">(${product.rating.count})</span>
                    </div>
                    <p class="product-price">$${product.price}</p>
                    <button class="quick-view-btn" data-id="${product.id}">Quick View</button>
                </div>
            `;
            productGrid.innerHTML += productCard;
        });


        // Add event listeners to new buttons
        document.querySelectorAll('.quick-view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = e.target.getAttribute('data-id');
                const product = products.find(p => p.id == productId);
                showQuickView(product);
            });
        });
    }

    // 6. Show Modal with Product Details
    function showQuickView(product) {
        modalBody.innerHTML = `
            <div class="modal-content-inner">
                <div class="modal-image-col">
                    <img src="${product.image}" alt="${product.title}">
                </div>
                <div class="modal-details">
                    <span class="modal-category">${product.category.toUpperCase()}</span>
                    <h2>${product.title}</h2>
                    <div class="modal-rating-row">
                        <span class="stars">${getStars(product.rating.rate)}</span>
                        <span class="rating-text">${product.rating.rate} out of 5 stars (${product.rating.count} ratings)</span>
                    </div>
                    <p class="modal-description">${product.description}</p>
                    <p class="modal-price">$${product.price}</p>
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
            </div>
        `;
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';
    }


    // 7. Modal Closing Logic
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    });

    window.addEventListener('click', (e) => {
        if (e.target == modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }
    });

    // Initial fetch
    fetchProducts();
});